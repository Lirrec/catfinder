#pragma once
/*
**  Copyright (C) 2012 Aldebaran Robotics
**  See COPYING for the license
*/

#include <qi/detail/future_fwd.hpp>
#include <qi/detail/future.hxx>
