/* #undef qi_STATIC_BUILD */
