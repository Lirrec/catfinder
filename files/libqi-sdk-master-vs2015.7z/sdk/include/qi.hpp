#pragma once
/*
 * Copyright (c) 2012 Aldebaran Robotics. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the COPYING file.
 */

#ifndef _QI_QI_HPP_
# define _QI_QI_HPP_

# include <qi/macro.hpp>

QI_DEPRECATED_HEADER("Please use qi/path.hpp instead (if you need unicodeFacet, otherwise just remove this include");

# include <qi/path.hpp>

#endif  // _QI_QI_HPP_
