#pragma once
/*
**  Copyright (C) 2013 Aldebaran Robotics
**  See COPYING for the license
*/

#ifndef _QI_ANYVALUE_HPP_
#define _QI_ANYVALUE_HPP_

#include <qi/type/detail/anyreference.hpp>

#include <qi/type/detail/anyvalue.hpp>

#include <qi/type/detail/anyiterator.hpp>

#endif  // _QITYPE_ANYVALUE_HPP_
